import { create } from "zustand"
import * as XLSX from 'xlsx';
import type { RowData } from "@/types/table";
import { isTriangle } from "@/utils/dataCheck";

type TableStore = {
  table?: File
  isHydrated: boolean
  workbook?: XLSX.WorkBook
  selectedSheet?: XLSX.WorkSheet
  selectedSheetJSON?: RowData[]
  selectedCells?: RowData[]
  selectedSheetName?: string | undefined
  isValid?: boolean

  setIsHydrated: (isHydrated: boolean) => void
  setWorkbook: (workbook: XLSX.WorkBook) => void
  setSelectedSheetName: (selectedSheetName: string | undefined) => void

  getSheetNames: () => string[] | undefined
  setSelectedCells: (selectedCells: RowData[]) => void

}

export const useTableStore = create<TableStore>(
  (set, get) => ({
    table: undefined,
    isHydrated: false,

    setIsHydrated: (isHydrated) => set({ isHydrated }),
    setWorkbook: (workbook) => {
      const selected = workbook?.SheetNames[0];

      set({ workbook })
      get().setSelectedSheetName(selected)
    },
    setSelectedSheetName: (sheetName) => {
      if (!sheetName) {
        set({
          selectedSheetName: undefined,
          selectedSheet: undefined,
          selectedSheetJSON: undefined,
          isValid: undefined
        })
        return
      }

      const sheet = get().workbook?.Sheets[sheetName];
      if (!sheet) {
        set({
          selectedSheetName: undefined,
          selectedSheet: undefined,
          selectedSheetJSON: undefined,
          isValid: undefined
        })
        return
      }

      const jsonData = XLSX.utils.sheet_to_json<RowData>(sheet, { header: 1 });
      const isValid = isTriangle(jsonData);
      set({
        selectedSheetName: sheetName,
        selectedSheet: sheet,
        selectedSheetJSON: jsonData,
        isValid,
        selectedCells: jsonData.map((row) => row.map(() => 1))
      })
    },

    getSheetNames: () => get().workbook?.SheetNames,
    setSelectedCells: (selectedCells) => set({ selectedCells }),
  })
)
// export const useTableStore = create(
//   persist<TableStore>(
//     (set) => ({
//       table: undefined,
//       isHydrated: false,

//       setIsHydrated: (isHydrated) => set({ isHydrated }),
//       setTable: (table) => set({ table }),
//     })
//     , {
//       name: '',
//     })
// )
