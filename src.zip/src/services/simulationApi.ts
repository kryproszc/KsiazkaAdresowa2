export async function runFullSimulation(body: any) {
  const res = await fetch('http://localhost:8000/calc/full', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });

  if (!res.ok) throw new Error('Simulation failed');
  return res.json();
}

export async function getQuantiles(requestId: string, quantiles: number[]) {
  const res = await fetch('http://localhost:8000/calc/quantiles', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ request_id: requestId, quantiles }),
  });

  if (!res.ok) throw new Error('Quantiles fetch failed');
  return res.json();
}

export async function getPercentile(requestId: string, value: number, source: 'sim' | 'diff') {
  const res = await fetch('http://localhost:8000/calc/percentile', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ request_id: requestId, value, source }),
  });

  if (!res.ok) throw new Error('Percentile fetch failed');
  return res.json();
}
