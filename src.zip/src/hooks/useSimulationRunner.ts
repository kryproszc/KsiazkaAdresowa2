'use client';

import { useMutation } from '@tanstack/react-query';
import { runFullSimulation, getQuantiles } from '@/services/simulationApi';
import { useUltimateStore } from '@/stores/useUltimateStore';
import { useTableStore } from '@/stores/tableStore';

export function useSimulationRunner() {
  const {
    setRequestId,
    setHistogramData,
    setQuantileResult,
    setStats,
    quantileInput,
    simulationCount,
  } = useUltimateStore();

  const {
    clData,
    clWeights,
    selectedSheetJSON,
    selectedCells,
  } = useTableStore();

  // 👉 MUTACJA SYMULACJI
  const simulation = useMutation({
    mutationFn: async () => {
      const res = await runFullSimulation({
        cl_data: clData,
        cl_weights: clWeights,
        paid_data: selectedSheetJSON,
        paid_weights: selectedCells,
        triangle_raw: selectedSheetJSON,
        cl_weights_raw: clWeights,
        user_id: 'demo-user-123',
        nbr_samples: parseInt(simulationCount) || 1000, // ✅ przekazujemy wartość z UI
      });

      const bins = res.histogram?.bins ?? [];
      const counts = res.histogram?.counts ?? [];

      setRequestId(res.request_id);

      const formattedHistogram = bins.slice(0, -1).map((start: number, i: number) => ({
        bin: `${start.toLocaleString('pl-PL')} - ${bins[i + 1].toLocaleString('pl-PL')}`,
        count: counts[i],
      }));

      setHistogramData(formattedHistogram);

      // automatyczne pobranie kwantyli
      const quantiles = quantileInput
        .split(',')
        .map((q) => parseFloat(q.trim()))
        .filter((q) => !isNaN(q) && q >= 0 && q <= 1);

      const quantileData = await getQuantiles(res.request_id, quantiles);
      setQuantileResult(quantileData.quantiles);
      setStats(quantileData.stats ?? null);
    },
  });

  // 👉 FUNKCJA DO POBIERANIA KWANTYLI osobno
  const refetchQuantiles = async (requestId: string) => {
    const quantiles = quantileInput
      .split(',')
      .map((q) => parseFloat(q.trim()))
      .filter((q) => !isNaN(q) && q >= 0 && q <= 1);

    const data = await getQuantiles(requestId, quantiles);
    setQuantileResult(data.quantiles);
    setStats(data.stats ?? null);
  };

  return {
    mutate: simulation.mutate,
    mutateAsync: simulation.mutateAsync, // ✅ dodajemy to, by działało await
    isPending: simulation.isPending,
    refetchQuantiles,
  };
}
