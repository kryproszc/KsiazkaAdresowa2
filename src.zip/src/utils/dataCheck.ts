export type RowData = Record<string, any>;

export function isTriangle(sheet: RowData[]): boolean {
  let prevCount = Infinity;
  let firstCount = Infinity;
  let isEnd = false;

  for (let i = 0; i < sheet.length; i++) {
    const row = sheet[i];
    const values = row?.length ?? 0;
    if (values == 0) {
      isEnd = true
      continue
    } else if (isEnd) {
      return false
    }

    if (i === 0 || !row) {
      firstCount = values;
      continue;
    }
    if (i == 1 && values != firstCount) {
      return false;
    }

    if (values >= prevCount) {
      return false;
    }

    prevCount = values;
  }

  return prevCount == 2;
}
