import HomePageClient from "./page.client";

export default function HomePage() {
  return (
    <main className="flex min-h-screen flex-col items-center bg-gradient-to-b from-[#1a1a2e] via-[#16213e] to-[#0f3460] text-white">
      <div className="w-full h-full flex flex-col  justify-center gap-12 px-4 py-16">
        {/* <h1 className="font-extrabold text-5xl text-white tracking-tight sm:text-[5rem]"> */}
        {/*   Beautiful <span className="text-[hsl(280,100%,70%)]">Database</span> App */}
        {/* </h1> */}
        <HomePageClient />
      </div>
    </main>
  );
}
