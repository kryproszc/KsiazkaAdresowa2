'use client';
import { TableData } from "@/components/TableData";
import { useTableStore } from "@/stores/tableStore";

export function PaidView() {
  const sheetName = useTableStore((state) => state.selectedSheetName);
  const sheetJSON = useTableStore((state) => state.selectedSheetJSON);
  const selectedCells = useTableStore((state) => state.selectedCells);
  const setSelectedCells = useTableStore((state) => state.setSelectedCells);

  if (!sheetJSON) return <div>No sheet</div>

  return (
    <div className="w-full p-4 border rounded">
      <h2 className="font-bold mb-2">Sheet: {sheetName}</h2>
      <TableData
        data={sheetJSON}
        selected={selectedCells}
        onClick={(x, y) => {
          if (!selectedCells) return
          const newSelectedCells = [...selectedCells];
          if (!newSelectedCells[x]) return
          newSelectedCells[x][y] = newSelectedCells[x][y] == 1 ? 0 : 1;
          setSelectedCells(newSelectedCells);
        }}
      />
    </div>
  )
}
