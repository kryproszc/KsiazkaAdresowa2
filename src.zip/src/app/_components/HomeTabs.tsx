import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs"
import { InputDataTab } from "./InputDataTab"
import { DeterministicTabs } from "./DeterministicTabs"

export function HomeTabs() {
  return (
    <Tabs defaultValue="input" className="w-full h-full">
      <TabsList className="grid w-full grid-cols-2">
        <TabsTrigger value="input">Wprowadź dane</TabsTrigger>
        <TabsTrigger value="deterministic">Metody deterministyczne</TabsTrigger>
      </TabsList>
      <TabsContent value="input">
        <InputDataTab />
      </TabsContent>
      <TabsContent value="deterministic">
        <DeterministicTabs />
      </TabsContent>
    </Tabs>
  )
}
