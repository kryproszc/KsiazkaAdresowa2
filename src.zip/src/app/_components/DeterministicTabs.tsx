import { PaidTabs } from "./PaidTabs";

export function DeterministicTabs() {
  return (
    <div className="w-full">
      <PaidTabs />
    </div>
  );
}
