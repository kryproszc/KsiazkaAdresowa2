import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs"
import { InputDataView } from "./InputDataView"
import { PaidTabs } from "./PaidTabs"

export function DeterministicTabs() {
  return (
    <Tabs defaultValue="a" className="w-full">
      <TabsList className="grid w-full grid-cols-3">
        <TabsTrigger value="a">A Paid</TabsTrigger>
        <TabsTrigger value="i">A Incurrel</TabsTrigger>
        <TabsTrigger value="result">Wynik końcowy</TabsTrigger>
      </TabsList>
      <TabsContent value="a">
        <PaidTabs />
      </TabsContent>
      <TabsContent value="i">
        Incurel
      </TabsContent>
      <TabsContent value="result">
        RESULT
      </TabsContent>
    </Tabs>
  )
}
