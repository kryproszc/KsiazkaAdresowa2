'use client';

import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useTableStore } from "@/stores/tableStore";
import { Button } from "@/components/ui/button";

export function UltimateTab() {
  const {
    processedTriangle,
    selectedCells,
    selectedSheetJSON,
    clData,
    clWeights,
  } = useTableStore();

  const [result, setResult] = useState<any>(null);

  const mutation = useMutation({
    mutationFn: async () => {
      if (!processedTriangle || !clData || !clWeights || !selectedSheetJSON || !selectedCells) {
        throw new Error("Brakuje danych w store");
      }
  
      const response = await fetch("http://localhost:8000/calc/full", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          cl_data: clData,
          cl_weights: clWeights,
          paid_data: selectedSheetJSON,
          paid_weights: selectedCells,
          triangle_raw: selectedSheetJSON,   // ← 1. Trójkąt
          cl_weights_raw: clWeights,         // ← 2. Współczynniki CL
          user_id: "demo-user-123"
        }),
      });
  
      if (!response.ok) throw new Error("Błąd serwera");
  
      return response.json();
    },
    onSuccess: (data) => {
      console.log("✅ Odpowiedź z backendu:", data);
      setResult(data);
    },
    onError: (err) => {
      console.error("❌ Błąd wysyłki danych:", err);
    },
  });

  const handleSubmit = () => {
    mutation.mutate();
  };

  return (
    <div className="flex flex-col gap-6 p-6">
      <h3 className="text-xl font-bold text-white">Wyślij dane do przeliczenia</h3>

      <Button
        onClick={handleSubmit}
        className="w-fit px-4 py-2 rounded bg-slate-700 hover:bg-slate-600 text-white font-medium"
      >
        Zatwierdź wszystko
      </Button>

      {result && (
        <div className="text-white mt-4">
          <h4 className="font-semibold">Odpowiedź z backendu:</h4>
          <pre className="text-sm bg-black/30 p-4 rounded whitespace-pre-wrap">{JSON.stringify(result, null, 2)}</pre>
        </div>
      )}
    </div>
  );
}
