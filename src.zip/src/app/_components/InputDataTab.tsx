'use client';

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import z from "zod";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useTableStore } from "@/stores/tableStore";
import * as XLSX from 'xlsx';
import { useEffect, useState } from "react";
import { SheetSelect } from "@/components/SheetSelect";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import {
  AlertDialog,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"


const schema = z.object({
  rowStart: z.number(),
  rowEnd: z.number(),
  colStart: z.number(),
  colEnd: z.number(),
  file: z.any(),
})

type FormField = z.infer<typeof schema>

export function InputDataTab() {
  const workbook = useTableStore((state) => state.workbook);
  const setWorkbook = useTableStore((state) => state.setWorkbook);
  const isValid = useTableStore((state) => state.isValid);
  const getDefaultRange = useTableStore((state) => state.getDefaultRange);
  const updateSheetJSON = useTableStore((state) => state.updateSheetJSON);

  const setStartRow = useTableStore((state) => state.setStartRow);
  const setEndRow = useTableStore((state) => state.setEndRow);
  const setStartCol = useTableStore((state) => state.setStartCol);
  const setEndCol = useTableStore((state) => state.setEndCol);

  const [showDialog, setShowDialog] = useState(false);

  useEffect(() => {
    if (isValid === false) {
      setShowDialog(true);
    }
  }, [isValid])

  const {
    register,
    handleSubmit,
    formState: { errors },
    watch,
    setValue,
  } = useForm<FormField>({
    defaultValues: {
      rowStart: 1,
      colStart: 1,
      colEnd: 1,
      rowEnd: 1
    },
    resolver: zodResolver(schema),
  });

  const file = watch("file");

  useEffect(() => {
    setWorkbook(undefined);
  }, [file]);

  const handleFileLoad = () => {
    const f = file?.[0];
    if (!f) {
      alert("Najpierw wybierz plik.");
      return;
    }

    const reader = new FileReader();

    reader.onload = (evt) => {
      const binaryStr = evt.target?.result;
      const workbook = XLSX.read(binaryStr, { type: "binary" });
      setWorkbook(workbook);
    };

    reader.readAsBinaryString(f);
  };

  const handleAutoRange = () => {
    const rangge = getDefaultRange();
    if (!rangge) return;
    setValue("rowStart", rangge.startRow);
    setValue("rowEnd", rangge.endRow);
    setValue("colStart", rangge.startCol);
    setValue("colEnd", rangge.endCol);
  }

  const onSubmit = async (data: FormField) => {
    setStartRow(data.rowStart);
    setEndRow(data.rowEnd);
    setStartCol(data.colStart);
    setEndCol(data.colEnd);

    updateSheetJSON();
  };

  return (
    <div>
      <form onSubmit={handleSubmit(onSubmit)} className="p-4 border rounded flex flex-col gap-4">
        <Card>
          <CardHeader>
            <CardTitle>Wprowadź dane</CardTitle>
            <CardDescription>
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="flex gap-4">
              <input
                className="border p-2 rounded-lg"
                type="file"
                multiple={false}
                {...register("file")}
              />
              <Button
                type="submit"
                className="bg-blue-500 text-white py-2 px-4 rounded"
                disabled={!file || file.length === 0}
                onClick={handleFileLoad}
              >
                Wyślij
              </Button>
            </div>
            {workbook && (
              <div className="grid gap-4">
                <div>
                  <Label className="p-2">Wiersz arkusz</Label>
                  <SheetSelect />
                </div>
                <div>
                  <Label className="p-2">Wiersz początkowy</Label>
                  <Input type="number" {...register("rowStart")} />
                </div>
                <div>
                  <Label className="p-2">Kolumna początkowa</Label>
                  <Input type="number" {...register("colStart")} />
                </div>
                <div>
                  <Label className="p-2">Wiersz końcowy</Label>
                  <Input type="number" {...register("rowEnd")} />
                </div>
                <div>
                  <Label className="p-2">Kolumna końcowa</Label>
                  <Input type="number" {...register("colEnd")} />
                </div>
                <div>
                  <Button
                    type="button"
                    variant="outline"
                    className="bg-blue-500 text-white py-2 px-4 rounded"
                    onClick={() => handleAutoRange()}
                  >
                    Wykryj zakres automatycznie
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
          <CardFooter>
            {workbook && (
              <Button
                type="submit"
                className="bg-blue-500 text-white py-2 px-4 rounded"
              >
                Wybierz
              </Button>
            )}
          </CardFooter>
        </Card>
      </form>

      <AlertDialog open={showDialog} onOpenChange={setShowDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Nieprawidłowe dane</AlertDialogTitle>
            <AlertDialogDescription>
              Wprowadzone dane są niepoprawne. Sprawdź formularz i spróbuj ponownie.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Zamknij</AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
