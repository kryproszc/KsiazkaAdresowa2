import { calcClCalcClPostMutation } from "@/client/@tanstack/react-query.gen";
import { Button } from "@/components/ui/button";
import { useTableStore } from "@/stores/tableStore";
import { useMutation } from "@tanstack/react-query";
import { useState } from "react";

export function CLTab() {
  const sheetJSON = useTableStore((state) => state.selectedSheetJSON);
  const selectedCells = useTableStore((state) => state.selectedCells);
  const [cl1, setCL1] = useState(0);
  const [cl2, setCL2] = useState(0);

  const calcCL = useMutation({
    ...calcClCalcClPostMutation(),
    onError: (error) => {
      console.log(error);
    },
    onSuccess: (data) => {
      const d = data as { cl1: number, cl2: number }
      setCL1(d.cl1);
      setCL2(d.cl2);
    }
  })

  const onCalc = () => {
    if (!sheetJSON) return

    calcCL.mutate({
      body: {
        data: sheetJSON,
        selected: selectedCells ?? []
      }
    })
  }

  return (
    <div>
      <div>CLTab</div>
      <div>CL1: {cl1}</div>
      <div>CL2: {cl2}</div>
      <Button onClick={onCalc}>Calc CL</Button>
    </div>
  )
}
