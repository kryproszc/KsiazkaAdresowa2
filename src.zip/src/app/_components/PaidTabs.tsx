import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs"
import { PaidView } from "./PaidView"
import { CLTab } from "./CLTab"
import { UltimateTab } from "./UltimateTab"

export function PaidTabs() {
  return (
    <Tabs defaultValue="triangle" className="w-full">
      <TabsList className="flex flex-grow w-full">
        <TabsTrigger value="triangle">1. Trójkąt</TabsTrigger>
        <TabsTrigger value="cl">2. Współczynnik CL</TabsTrigger>
        <TabsTrigger value="ultimate">3. Ultimate</TabsTrigger>
        <TabsTrigger value="curve">4. Dopasowanie krzywej CL</TabsTrigger>
        <TabsTrigger value="curve-select">5. Wybór krzywej CL</TabsTrigger>
        <TabsTrigger value="results">6. Wyniki</TabsTrigger>
      </TabsList>
      <TabsContent value="triangle">
        <PaidView />
      </TabsContent>
      <TabsContent value="cl">
        <CLTab />
      </TabsContent>
      <TabsContent value="ultimate">
        <UltimateTab />
      </TabsContent>
      <TabsContent value="curve">
        Dopasowanie krzywej CL
      </TabsContent>
      <TabsContent value="curve-select">
        Wybór krzywej CL
      </TabsContent>
      <TabsContent value="results">
        Wyniki
      </TabsContent>
    </Tabs>
  )
}
