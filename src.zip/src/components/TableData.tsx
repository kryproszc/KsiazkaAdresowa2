import type { RowData } from '@/types/table';
import { useState } from 'react';

interface Props {
  data: RowData[];
  selected?: RowData[];
  onClick?: (x: number, y: number) => void;
}

export function TableData({
  data,
  selected,
  onClick
}: Props) {
  return (
    <div className="overflow-auto rounded border">
      <table className="min-w-full table-auto border-collapse">
        <thead className="text-left text-sm font-medium text-gray-700 bg-gray-900 dark:text-gray-200">
          <tr>
            {data[0] && data[0].map((value, i) => (
              <th key={i} className="px-4 py-2  border-b">
                {value}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="text-sm text-white">
          {data.slice(1).map((row, i) => (
            <tr
              key={i}
              className="odd:bg-gray-800 even:bg-gray-700 transition"
            >
              {row.map((cell, j) => (
                <td
                  key={j}
                  className={`px-4 py-2 border-b whitespace-nowrap hover:bg-blue-900
 ${selected && selected[i] && selected[i][j] == 1 ? "" : "bg-gray-900 brightness-50"}
`}
                  onClick={() => {
                    {/* if (!selected[i] || selected[i][j] == undefined) return */ }
                    {/* selected[i][j] = selected[i][j] == 1 ? 0 : 1 */ }
                    onClick && onClick(i, j)
                  }}
                >
                  {cell}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
