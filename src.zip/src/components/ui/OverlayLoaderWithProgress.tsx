'use client';

import { useEffect, useState } from 'react';
import { Loader2 } from 'lucide-react';

export function OverlayLoaderWithProgress() {
  const [progress, setProgress] = useState(5);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((p) => (p < 95 ? p + Math.random() * 5 : p));
    }, 300);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="fixed inset-0 bg-black/30 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-[#1e1e2f] text-white px-10 py-8 rounded-3xl shadow-2xl flex flex-col items-center gap-5 min-w-[340px]">
        <Loader2 className="animate-spin w-10 h-10 text-white/80" />
        <div className="w-full bg-white/10 h-3 rounded-full overflow-hidden">
          <div
            className="bg-gradient-to-r from-white via-white/80 to-white/60 h-3 transition-all"
            style={{ width: `${progress}%` }}
          />
        </div>
        <p className="text-base font-medium text-white/90 tracking-wide">
          Ładowanie... {Math.round(progress)}%
        </p>
      </div>
    </div>
  );
}
